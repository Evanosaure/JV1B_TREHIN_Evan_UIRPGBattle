function enemyattackplayer1()
{
  evil1.animate(
  // keyframes
  [
    { transform: 'translateX(-50px)' },
    { transform: 'translateX(0)' },
  ], 
  // timing options
  {
    duration: 200,
  });
  viej1.innerHTML -= 2;
  return viej1;
}

function enemyattackplayer2()
{
  evil2.animate(
  // keyframes
  [
    { transform: 'translateX(-50px)' },
    { transform: 'translateX(0)' },
  ], 
  // timing options
  {
    duration: 200,
  });
  viej1.innerHTML -= 2;
  return viej1;
}

function enemyattackplayer3()
{
  evil3.animate(
  // keyframes
  [
    { transform: 'translateX(-50px)' },
    { transform: 'translateX(0)' },
  ], 
  // timing options
  {
    duration: 200,
  });
  viej1.innerHTML -= 2;
  return viej1;
}

function playerattackenemy1()
{
  chara1.animate(
  // keyframes
  [
    { transform: 'translateX(-50px)' },
    { transform: 'translateX(0)' },
  ], 
  // timing options
  {
    duration: 200,
  });
  viej1.innerHTML -= 2;
  return viej1;
}

function playerattackenemy2()
{
  chara2.animate(
  // keyframes
  [
    { transform: 'translateX(-50px)' },
    { transform: 'translateX(0)' },
  ], 
  // timing options
  {
    duration: 200,
  });
  viej1.innerHTML -= 2;
  return viej1;
}

function playerattackenemy3()
{
  chara3.animate(
  // keyframes
  [
    { transform: 'translateX(-50px)' },
    { transform: 'translateX(0)' },
  ], 
  // timing options
  {
    duration: 200,
  });
  viej1.innerHTML -= 2;
  return viej1;
}


function playerattackenemy4()
{
  chara4.animate(
  // keyframes
  [
    { transform: 'translateX(-50px)' },
    { transform: 'translateX(0)' },
  ], 
  // timing options
  {
    duration: 200,
  });
  viej1.innerHTML -= 2;
  return viej1;
}


attack1.onclick = playerattackenemy1() 

attack2.onclick = playerattackenemy2() 

attack3.onclick = playerattackenemy3() 

attack4.onclick = playerattackenemy4() 

enemyattackplayer1()

enemyattackplayer2()

enemyattackplayer3()